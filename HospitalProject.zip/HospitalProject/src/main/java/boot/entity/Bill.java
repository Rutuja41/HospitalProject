package boot.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@DynamicUpdate
@AllArgsConstructor
@NoArgsConstructor
public class Bill {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "patient_id")
	private Patient patient;

	@Column(name = "Date")
	private LocalDateTime billDate;

	@Column(name = "Amount")
	private double totalAmount;

	@Column(name = "Status")
	private String paymentStatus;
	
public Bill() {
    	
    }
	public Long getId() {
		return id;
	}

	public Patient getPatient() {
		return patient;
	}

	public LocalDateTime getBillDate() {
		return billDate;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public String getPaymentStatus() {
		return paymentStatus;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public void setBillDate(LocalDateTime billDate) {
		this.billDate = billDate;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	@Override
	public String toString() {
		return "Bill [id=" + id + ", patient=" + patient + ", billDate=" + billDate + ", totalAmount=" + totalAmount
				+ ", paymentStatus=" + paymentStatus + "]";
	}
	
	
	

/*	public void setBillDate(LocalDateTime now) {
		this.billDate = now;
	}
*/
}
