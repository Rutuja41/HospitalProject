package boot.entity;

import lombok.Data;

@Data
public class Login {

	//private String eMail;	
	private String email;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private String password;
	private String userType;
/*	public String geteMail() {
		return eMail;
	}
	public void seteMail(String eMail) {
		this.eMail = eMail;
	}*/
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	@Override
	public String toString() {
		return "Login [email=" + email + ", password=" + password + ", userType=" + userType + "]";
	}
	public Login(String eMail, String password, String userType) {
		super();
		this.email = email;
		this.password = password;
		this.userType = userType;
	}

	
}
