package boot.dto;

import lombok.Data;

@Data
public class PatientDTO {

	 
	    private Long id;
	    private String name;
	    private String email;
	    private String Password;
	    private String age;
	    private String gender;
	    private String phone;
	    private String address;
	    private String City;
	    
	    public PatientDTO() {
	    	
	    }
	    
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return Password;
		}
		public void setPassword(String password) {
			Password = password;
		}
		public String getAge() {
			return age;
		}
		public void setAge(String age) {
			this.age = age;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getCity() {
			return City;
		}
		public void setCity(String city) {
			this.City = city;
		}
		@Override
		public String toString() {
			return "PatientDTO [id=" + id + ", name=" + name + ", email=" + email + ", Password=" + Password + ", age="
					+ age + ", gender=" + gender + ", phone=" + phone + ", address=" + address + ", City=" + City + "]";
		}
		public PatientDTO(Long id, String name, String email, String password, String age, String gender, String phone,
				String address, String city) {
			super();
			this.id = id;
			this.name = name;
			this.email = email;
			this.Password = password;
			this.age = age;
			this.gender = gender;
			this.phone = phone;
			this.address = address;
			this.City = city;
		}
		
}
