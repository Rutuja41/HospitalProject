package boot.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BillDTO {

	private Long id;
	private PatientDTO patient;

	private LocalDateTime billDate;
	private double totalAmount;
	private String paymentStatus;
	

    public BillDTO() {
    	
    	
    }


	public Long getId() {
		return id;
	}


	public PatientDTO getPatient() {
		return patient;
	}


	public LocalDateTime getBillDate() {
		return billDate;
	}


	public double getTotalAmount() {
		return totalAmount;
	}


	public String getPaymentStatus() {
		return paymentStatus;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public void setPatient(PatientDTO patient) {
		this.patient = patient;
	}


	public void setBillDate(LocalDateTime billDate) {
		this.billDate = billDate;
	}


	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
    
}
